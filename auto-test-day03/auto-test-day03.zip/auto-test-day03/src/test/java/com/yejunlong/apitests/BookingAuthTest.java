package com.yejunlong.apitests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;


public class BookingAuthTest {

    public static String authToken;

    @BeforeClass
    public void setUp(){
        RestAssured.proxy("127.0.0.1", 7897);
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
    }

    /**
     * 测试用例1：获取 Token
     */
    @Test
    public void testGetToken(){
        String requestBody = "{\"username\":\"admin\",\"password\":\"password123\"}";

        Response response = given()
                .contentType("application/json")
                .body(requestBody)
        .when()
                .post("/auth");

        //打印响应
        response.prettyPrint();

        //提取Token
        authToken = response.jsonPath().getString("token");
        System.out.println(" 提取的 Token 为： " + authToken);

        //断言Token不为空
        Assert.assertNotNull(authToken,"Token 不应为空");
        Assert.assertNotEquals(authToken,"","Token 不应为空字符串");
    }

    /**
     * 测试用例2：使用 Token 查询订单（依赖 testGetToken）
     */
    @Test(dependsOnMethods = {"testGetToken"})
    public void testGetBookingWithTonken(){
        given()
                .header("Cookie","token="+authToken)
        .when()
                .get("/booking/1")
        .then()
                .statusCode(200)
                .log().body();
    }

}
