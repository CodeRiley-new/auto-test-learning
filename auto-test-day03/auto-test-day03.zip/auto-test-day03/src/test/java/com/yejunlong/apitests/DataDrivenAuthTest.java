package com.yejunlong.apitests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class DataDrivenAuthTest {

    @BeforeClass
    public void setUp(){
        RestAssured.proxy("127.0.0.1", 7897);
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
    }

    @DataProvider(name = "authData")
    public Object[][] authData(){
        return new Object[][]{
                {"admin", "password123",true},
                {"admin","wrong",false},
                {"","password123",false},
                {"admin","",false}
        };
    }

    @Test(dataProvider = "authData")
    public void testAuth(String username,String password,boolean shouldSucceed){
        String requestBody = "{\"username\":\""+username+"\",\"password\":\""+password+"\"}";

        Response response = given()
                .contentType("application/json")
                .body(requestBody)
        .when()
                .post("/auth");

        response.then().statusCode(200);

        String token = response.jsonPath().getString("token");

        if (shouldSucceed) {
            Assert.assertNotNull(token,"正确凭证返回token");
            System.out.println(" 正确凭证, Token： " +token);
        }else {
            Assert.assertNull(token,"错误凭证应返回null");
            System.out.println(" 错误凭证, Token为null " );
        }
    }
}
