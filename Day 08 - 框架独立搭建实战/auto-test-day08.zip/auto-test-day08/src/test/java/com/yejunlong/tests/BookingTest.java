package com.yejunlong.tests;

import com.yejunlong.api.AuthApi;
import com.yejunlong.api.BookingApi;
import com.yejunlong.config.ApiConfig;
import com.yejunlong.model.AuthResponse;
import com.yejunlong.model.BookingRequest;
import com.yejunlong.model.BookingResponse;
import com.yejunlong.utils.AssertUtils;
import com.yejunlong.utils.JsonUtils;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class BookingTest {

    private static String authToken;
    private static int bookingId;

    @Test
    public void testLogin(){

        //登入获取token
        Response response = AuthApi.login(ApiConfig.TEST_USERNAME,ApiConfig.TEST_PASSWORD);
        AssertUtils.assertSuccess(response);
        AuthResponse authResponse = JsonUtils.fromJson(response.getBody().asString(),AuthResponse.class);
        authToken = authResponse.getToken();
        AssertUtils.assertTokenValid(authToken);
        System.out.println("登入成功,token:"+authToken);
    }

    //创建订单
    @Test(dependsOnMethods = "testLogin")
    public void testCreateBooking(){
        BookingRequest request = new BookingRequest();
        request.setFirstname("张三");
        request.setLastname("测试");
        request.setTotalprice(150);
        request.setDepositpaid(true);

        BookingRequest.BookingDates dates = new BookingRequest.BookingDates();
        dates.setCheckin("2026-07-24");
        dates.setCheckout("2020-07-26");
        request.setBookingdates(dates);
        request.setAdditionalneeds("创建订单测试");

        Response response = BookingApi.createBooking(request);
        AssertUtils.assertSuccess(response);

        BookingResponse bookingResponse = JsonUtils.fromJson(response.getBody().asString(),BookingResponse.class);
        bookingId = bookingResponse.getBookingid();
        System.out.println("创建订单成功,订单号:"+bookingId);
    }

    //查询订单
    @Test(dependsOnMethods = {"testCreateBooking","testLogin"})
    public void testGetBooking(){
        Response response = BookingApi.getBooking(authToken,bookingId);
        AssertUtils.assertSuccess(response);
        AssertUtils.assertFieldExist(response,"firstname");

        String firstname = response.getBody().jsonPath().getString("firstname");
        Assert.assertEquals(firstname,"张三","查询到的姓名与创建时的不一致");
        System.out.println("查询订单成功,姓名:"+firstname);
    }
}
