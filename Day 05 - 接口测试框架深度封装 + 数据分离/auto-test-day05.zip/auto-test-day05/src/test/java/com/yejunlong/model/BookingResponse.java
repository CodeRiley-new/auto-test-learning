package com.yejunlong.model;

import lombok.Data;

/**
 * 创建订单响应的 POJO 类
 * 对应 JSON: {"bookingid": 123, "booking": {...}}
 */
@Data
public class BookingResponse {

    private int bookingid;
    private BookingRequest booking;
}
