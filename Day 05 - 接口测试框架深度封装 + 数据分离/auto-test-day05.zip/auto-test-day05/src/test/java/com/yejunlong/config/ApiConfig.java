package com.yejunlong.config;


/**
 * API 配置管理
 * 作用：集中管理所有配置，方便切换环境
 */
public class ApiConfig {

    //环境配置
    public static final String ENV = "test";

    //不同环境的 Base URL
    private static final String BASE_URL_TEST = "https://restful-booker.herokuapp.com";
    private static final String BASE_URL_PROD = "https://restful-booker.herokuapp.com";

    //代理配置
    public static final String PROXY_HOST = "127.0.0.1";
    public static final int PROXY_PORT = 7897;

    //测试数据
    public static final String TEST_USERNAME = "admin";
    public static final String TEST_PASSWORD = "password123";

    //根据环境获取 Base URL
    public static String getBaseUrl() {
        if ("prod".equalsIgnoreCase(ENV)) {
            return BASE_URL_PROD;
        }
        return BASE_URL_TEST;
    }
}
