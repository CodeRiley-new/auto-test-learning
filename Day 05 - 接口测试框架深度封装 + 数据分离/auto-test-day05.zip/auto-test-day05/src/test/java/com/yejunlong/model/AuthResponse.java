package com.yejunlong.model;

import lombok.Data;

/**
 * 登录响应的 POJO 类
 * 对应 JSON: {"token": "xxx"} 或 {"reason": "Bad credentials"}
 */
@Data
public class AuthResponse {

    private String token;
    private String reason;


    //判断是否登录成功
    public boolean isSuccess() {
        return token != null && !token.isEmpty();
    }
}
