package com.yejunlong.model;

import lombok.Data;

/**
 * 创建订单请求的 POJO 类
 * 对应 JSON:
 * {
 *   "firstname": "张三",
 *   "lastname": "测试",
 *   "totalprice": 150,
 *   "depositpaid": true,
 *   "bookingdates": {"checkin": "2026-07-20", "checkout": "2026-07-22"},
 *   "additionalneeds": "早餐"
 * }
 */
@Data
public class BookingRequest {

    private String firstname;
    private String lastname;
    private int totalprice;
    private boolean depositpaid;
    private BookingDates bookingdates;
    private String additionalneeds;

    // 内部类:预订日期
    @Data
    public static class BookingDates {
        private String checkin;
        private String checkout;

        public BookingDates(){

        }

        public BookingDates(String checkin, String checkout) {
            this.checkin = checkin;
            this.checkout = checkout;
        }
    }

    public BookingRequest(){

    }
}
