package com.yejunlong.tests;

import com.yejunlong.api.AuthApi;
import com.yejunlong.api.BookingApi;
import com.yejunlong.config.ApiConfig;
import com.yejunlong.model.AuthResponse;
import com.yejunlong.model.BookingRequest;
import com.yejunlong.model.BookingResponse;
import com.yejunlong.utils.AssertUtils;
import com.yejunlong.utils.JsonUtils;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class BookingFlowTest {

    private static String authToken;
    private static int createdBookingId;

    /**
     * 测试用例1：登录获取 Token
     */
    @Test
    public void testLogin() {
        Response response = AuthApi.login(ApiConfig.TEST_USERNAME, ApiConfig.TEST_PASSWORD);

        //验证响应
        AssertUtils.assertSuccess(response);

        //将响应转化为对象
        AuthResponse authResponse = JsonUtils.fromJson(response.getBody().asString(), AuthResponse.class);

        //验证 Token
        authToken = authResponse.getToken();
        AssertUtils.assertTokenValid(authToken);
        System.out.println("登录成功，Token：" + authToken);
    }

    /**
     * 测试用例2：创建订单（依赖登录成功）
     */
    @Test(dependsOnMethods = "testLogin")
    public void testCreateBooking() {
        //构造请求数据（用POJO对象，不用JSON字符串）
        BookingRequest request = new BookingRequest();
        request.setFirstname("张三");
        request.setLastname("测试");
        request.setTotalprice(150);
        request.setDepositpaid(true);
        request.setAdditionalneeds("早餐");

        BookingRequest.BookingDates dates = new BookingRequest.BookingDates();
        dates.setCheckin("2026-07-20");
        dates.setCheckout("2026-07-22");
        request.setBookingdates(dates);

        //发送请求
        Response response = BookingApi.createBooking(request);

        //验证响应
        AssertUtils.assertSuccess(response);

        //将响应转换为对象
        BookingResponse bookingResponse = JsonUtils.fromJson(response.getBody().asString(), BookingResponse.class);

        //验证
        createdBookingId = bookingResponse.getBookingid();
        Assert.assertTrue(createdBookingId > 0, "订单编号应大于 0");

        BookingRequest createdBooking = bookingResponse.getBooking();
        Assert.assertEquals(createdBooking.getFirstname(), "张三", "预订人姓氏不匹配");
        Assert.assertEquals(createdBooking.getTotalprice(),150, "价格不匹配");

        System.out.println("创建订单成功，订单 ID：" + createdBookingId);
    }

    /**
     * 测试用例3：查询订单（依赖登录成功 + 创建订单成功）
     */
    @Test(dependsOnMethods = {"testLogin","testCreateBooking"})
    public void testGetBooking() {
        Response response = BookingApi.getBooking(authToken, createdBookingId);

        AssertUtils.assertSuccess(response);
        AssertUtils.assertFieldExists(response, "firstname");
        AssertUtils.assertFieldExists(response,"lastname");

        System.out.println("查询订单成功，订单 ID：" + createdBookingId);
    }

    /**
     * 测试用例4：完整流程测试
     * 依赖：登录 → 创建订单 → 查询订单
     */
    @Test(dependsOnMethods = {"testLogin","testCreateBooking","testGetBooking"})
    public void testFullFlow() {
        System.out.println("完整流程测试通过：登录 → 创建订单 → 查询订单");
    }
}
