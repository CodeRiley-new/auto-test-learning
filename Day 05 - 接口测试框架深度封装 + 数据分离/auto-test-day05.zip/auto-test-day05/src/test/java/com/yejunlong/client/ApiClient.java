package com.yejunlong.client;

import com.yejunlong.config.ApiConfig;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

/**
 * 统一的 API 请求客户端
 * 作用：封装所有请求的公共部分（代理、Content-Type、日志）
 */
public class ApiClient {

    static {
        RestAssured.proxy(ApiConfig.PROXY_HOST, ApiConfig.PROXY_PORT);
        RestAssured.baseURI = ApiConfig.getBaseUrl();
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * 发送 POST 请求（带 JSON Body）
     * @param path 接口路径，如 "/auth"
     * @param body JSON 字符串
     * @return 响应对象
     */
    public static Response post(String path, String body) {
        return given()
                .contentType(ContentType.JSON)
                .body(body)
                .log().all()
        .when()
                .post(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 GET 请求（带路径参数）
     * @param path 接口路径，如 "/booking/1"
     * @return 响应对象
     */
    public static Response get(String path) {
        return given()
                .log().all()
        .when()
                .get(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 GET 请求（带 Token）
     * @param path 接口路径
     * @param token 认证 Token
     * @return 响应对象
     */
    public static Response getWithToken(String path, String token) {
        return given()
                .header("Cookie", "token=" + token)
                .log().all()
        .when()
                .get(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 PUT 请求（带 Token + JSON Body）
     */
    public static Response putWithToken(String path, String token, String body) {
        return given()
                .contentType(ContentType.JSON)
                .header("Cookie", "token=" + token)
                .body(body)
                .log().all()
        .when()
                .put(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 DELETE 请求（带 Token）
     */
    public static Response deleteWithToken(String path, String token) {
        return given()
                .header("Cookie", "token=" + token)
                .log().all()
        .when()
                .delete(path)
        .then()
                .log().all()
                .extract().response();
    }
}
