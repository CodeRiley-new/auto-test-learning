package com.yejunlong.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * JSON 工具类
 * 作用：在 Java 对象和 JSON 字符串之间互相转换
 */
public class JsonUtils {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 将 Java 对象转换为 JSON 字符串
     */
    public static String toJson(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        }catch (Exception e){
            throw new RuntimeException("对象转JSON失败："+e.getMessage(),e);
        }
    }

    /**
     * 将 JSON 字符串转换为 Java 对象
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        }catch (Exception e){
            throw new RuntimeException("JSON转对象失败："+e.getMessage(),e);
        }
    }
}
