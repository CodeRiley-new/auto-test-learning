package com.yejunlong.api;

import com.yejunlong.client.ApiClient;
import com.yejunlong.model.BookingRequest;
import com.yejunlong.utils.JsonUtils;
import io.restassured.response.Response;

/**
 * 订单相关的 API 接口封装
 */
public class BookingApi {
    //接口路径常量
    public static final String BOOKING_PATH = "/booking";

    //创建订单
    public static Response createBooking(BookingRequest request) {
        String jsonBody = JsonUtils.toJson(request);
        return ApiClient.post(BOOKING_PATH, jsonBody);
    }

    //查询订单（使用 Token）
    public static Response getBooking(String token ,int bookingId) {
        return ApiClient.getWithToken(BOOKING_PATH + "/" + bookingId, token);
    }

    //更新订单（使用 Token）
    public static Response updateBooking(String token, int bookingId, BookingRequest request) {
        String jsonBody = JsonUtils.toJson(request);
        return ApiClient.putWithToken(BOOKING_PATH + "/" + bookingId,token, jsonBody);
    }

    //删除订单（使用 Token）
    public static Response deleteBooking(String token, int bookingId) {
        return ApiClient.deleteWithToken(BOOKING_PATH + "/" + bookingId, token);
    }
}
