package com.yejunlong.model;

import lombok.Data;

/**
 * 登录请求的 POJO 类
 * 对应 JSON: {"username":"admin", "password":"password123"}
 */
@Data
public class AuthRequest {

    private String username;
    private String password;

    public AuthRequest() {

    }

    public AuthRequest(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
