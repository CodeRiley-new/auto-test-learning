package com.yejunlong.api;

import com.yejunlong.client.ApiClient;
import com.yejunlong.model.AuthRequest;
import com.yejunlong.model.AuthResponse;
import com.yejunlong.utils.JsonUtils;
import io.restassured.response.Response;

/**
 * 认证相关的 API 接口封装
 */
public class AuthApi {

    //接口路径常量
    public static final String LOGIN_PATH = "/auth";

    /**
     * 登录：获取 Token
     * @param request 登录请求对象
     * @return 响应对象
     */
    public static Response login(AuthRequest request) {
        String jsonBody = JsonUtils.toJson(request);
        return ApiClient.post(LOGIN_PATH, jsonBody);
    }

    /**
     * 登录：直接用用户名密码
     */
    public static Response login(String username, String password) {
        AuthRequest request = new AuthRequest(username, password);
        return login(request);
    }
}
