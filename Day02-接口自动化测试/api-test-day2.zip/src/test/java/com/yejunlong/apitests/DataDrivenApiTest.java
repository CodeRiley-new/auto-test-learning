package com.yejunlong.apitests;

import io.restassured.RestAssured;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class DataDrivenApiTest {

    @DataProvider(name = "UserData")
    public Object[][] userData() {
        return new Object[][] {
             {"octocat", 200},
             {"defunkt", 200},
             {"nonexistent12345", 404}
        };
    }

    @Test(dataProvider = "UserData")
    public void testMultipleUsers(String username, int expectedStatusCode) {
        RestAssured.baseURI = "https://api.github.com";

        given()
                .pathParam("username", username)
        .when()
                .get("/users/{username}")
        .then()
                .statusCode(expectedStatusCode);

        System.out.println("用户"+username+"状态码："+expectedStatusCode);
    }
}
