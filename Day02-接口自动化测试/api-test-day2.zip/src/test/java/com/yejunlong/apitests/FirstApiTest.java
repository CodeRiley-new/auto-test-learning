package com.yejunlong.apitests;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class FirstApiTest {

    @BeforeClass
    public void setUp() {
        //设置基础URI,后续所有请求基于这个地址
        RestAssured.baseURI = "https://api.github.com";
    }

    /**
     * 测试用例1：GET请求——获取用户信息
     * 验证：状态码200+响应体包含用户名
     */
    @Test
    public void testGetUser() {
        given()
                .pathParam("username", "octocat")       //路径参数
        .when()
                .get("/users/{username}")                 //发送GET请求
        .then()
                .statusCode(200)                          //断言状态码
                .body("login", equalTo("octocat")) //断言响应体
                .body("id", greaterThan(0))
                .log().body();                              //打印响应体

        System.out.println("测试通过：成功获取用户octocat信息");
    }

    /**
     * 测试用例2：GET 请求 - 搜索仓库
     * 验证：状态码 200 + 搜索结果数量 > 0
     */
    @Test
    public void testSearchRepositories() {
        given()
                .queryParam("q", "selenium")
                .queryParam("per_page", 5)
        .when()
                .get("/search/repositories")
        .then()
                .statusCode(200)
                .body("items.size()", greaterThan(0))
                .body("total_count", greaterThan(0));

        System.out.println("测试通过：成功搜索到selenium仓库");
    }

    /**
     * 测试用例3：GET 请求 - 用户不存在（异常场景）
     * 验证：状态码 404
     */
    @Test
    public void testUserNotFound() {
        given()
                .pathParam("username", "thisuserdoesnotexist12345")
        .when()
                .get("/users/{username}")
        .then()
                .statusCode(404)
                .body("message", containsString("Not Found"));

        System.out.println("测试通过：用户不存在返回404");
    }
}
