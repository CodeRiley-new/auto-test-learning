package com.yejunlong.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.time.Duration;

public class SauceDemoTest {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "drivers/msedgedriver.exe");

        EdgeOptions options = new EdgeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--start-maximized");

        driver = new EdgeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    /**
     * 测试用例1：验证登录功能（正确账号）
     * 场景：输入正确用户名和密码，点击登录，验证是否进入商品列表页
     */
    @Test
    public void testLoginSuccess() {
        // 1. 打开 SauceDemo 首页
        driver.get("https://www.saucedemo.com/");

        // 2. 输入用户名
        driver.findElement(By.id("user-name")).sendKeys("standard_user");

        // 3. 输入密码
        driver.findElement(By.id("password")).sendKeys("secret_sauce");

        // 4. 点击登录按钮
        driver.findElement(By.id("login-button")).click();

        // 5. 等待商品列表容器出现，验证登录成功
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container")));
        boolean isInventoryDisplayed = driver.findElement(By.id("inventory_container")).isDisplayed();

        Assert.assertTrue(isInventoryDisplayed, "登录失败，未进入商品列表页");
        System.out.println("登录成功！已进入商品列表页");
    }

    /**
     * 测试用例2：验证登录失败（错误密码）
     * 场景：输入错误密码，验证是否显示错误提示
     */
    @Test
    public void testLoginFailed() {
        driver.get("https://www.saucedemo.com/");

        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("wrong_password");
        driver.findElement(By.id("login-button")).click();

        // 等待错误提示出现
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']")));
        String errorMsg = driver.findElement(By.cssSelector("[data-test='error']")).getText();

        System.out.println("错误提示：" + errorMsg);
        Assert.assertTrue(errorMsg.contains("Username and password do not match"), "错误提示内容不正确");
    }

    /**
     * 测试用例3：验证加入购物车功能
     * 场景：登录后，将第一个商品加入购物车，验证购物车角标变为 1
     */
    @Test
    public void testAddToCart() {
        // 第一步：登录
        driver.get("https://www.saucedemo.com/");
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container")));

        // 第二步：找到第一个商品的"Add to cart"按钮并点击
        // 用 XPath 定位第一个商品的按钮（更稳定）
        WebElement firstAddButton = driver.findElement(By.xpath("//div[@class='inventory_item'][1]//button"));
        firstAddButton.click();

        // 第三步：验证购物车角标从无变为 "1"
        String cartBadge = driver.findElement(By.className("shopping_cart_badge")).getText();
        System.out.println("🛒 购物车角标：" + cartBadge);
        Assert.assertEquals(cartBadge, "1", "加入商品后购物车角标应为1");
        System.out.println("商品已成功加入购物车");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("浏览器已关闭");
        }
    }
}