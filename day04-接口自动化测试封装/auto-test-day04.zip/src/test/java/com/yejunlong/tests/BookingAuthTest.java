package com.yejunlong.tests;

import com.yejunlong.client.ApiClient;
import com.yejunlong.utils.AssertUtils;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class BookingAuthTest {

    private static String authToken;

    /**
     * 测试用例1：获取 Token（使用封装后的 ApiClient）
     */
    @Test
    public void testGetToken() {
        //准备请求体
        String requestBody = "{\"username\":\"admin\",\"password\":\"password123\"}";

        //法松请求体
        Response response = ApiClient.post("/auth", requestBody);

        //提取token
        authToken = response.jsonPath().get("token");
        System.out.println("authToken = " + authToken);

        //断言
        AssertUtils.assertTokenValid(authToken);
        AssertUtils.assertSuccess(response);
    }

    /**
     * 测试用例2：使用 Token 查询订单（使用封装后的 ApiClient）
     */
    @Test(dependsOnMethods = {"testGetToken"})
    public void testGetBookingWithToken() {
        Response response = ApiClient.getWithToken("/booking/1", authToken);

        //断言
        AssertUtils.assertSuccess(response);

        //断言响应体包含firstname字段
        AssertUtils.assertFieldExist(response, "firstname");

        System.out.println("成功查询订单详细");
    }

    /**
     * 测试用例3：验证错误密码（Token 应为 null）
     */
    @Test
    public void testGetTokenWithWrongPassword() {
        String requestBody = "{\"username\":\"admin\",\"password\":\"wrong\"}";

        Response response = ApiClient.post("/auth", requestBody);

        String token = response.jsonPath().get("token");

        //密码错误应该返回null
        AssertUtils.assertSuccess(response);
        Assert.assertNull(token,"错误密码因返回null");

        System.out.println("错误密码测试通过，Token 为null");
    }
}
