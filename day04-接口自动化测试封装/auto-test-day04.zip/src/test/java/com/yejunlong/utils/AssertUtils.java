package com.yejunlong.utils;

import io.restassured.response.Response;
import org.testng.Assert;

/**
 * 统一的断言工具类
 * 作用：封装常用断言，减少重复代码，统一错误信息格式
 */
public class AssertUtils {

    /**
     * 断言请求成功：状态码 200
     */
    public static void assertSuccess(Response response) {
        Assert.assertEquals(
                response.getStatusCode(),
                200,
                "请求失败，状态码:"+response.getStatusCode()+", 响应体:"+response.getBody().asString()
        );
    }

    /**
     * 断言状态码
     */
    public static void assertStatus(Response response, int expectedCode) {
        Assert.assertEquals(
                response.getStatusCode(),
                expectedCode,
                "状态码不符，预期:"+expectedCode+", 实际:"+response.getStatusCode()
        );
    }

    /**
     * 断言 Token 有效（不为空）
     */
    public static void assertTokenValid(String token) {
        Assert.assertNotNull(token, "Token 不应为null");
        Assert.assertNotEquals(token, "", "Token 不应为空字符串");
    }

    /**
     * 断言响应体包含某个字段
     */
    public static void assertFieldExist(Response response, String jsonPath) {
        Object value = response.jsonPath().get(jsonPath);
        Assert.assertNotNull(value, "响应体不包含字段：'"+jsonPath+"'不存在或为null");
    }

    /**
     * 断言响应体字段等于预期值
     */
    public static void assertFieldEquals(Response response, String jsonPath, Object expected) {
        Object actual = response.jsonPath().get(jsonPath);
        Assert.assertEquals(actual, expected, "字段'"+jsonPath+"'的值不符，预期:"+expected+", 实际:"+actual);
    }
}
