package com.yejunlong.client;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

/**
 * 统一的 API 请求客户端
 * 作用：封装所有请求的公共部分（代理、Content-Type、日志）
 */
public class ApiClient {

    //静态状态码块：只执行一次，用于初始化
    static {
        //配置代理
        RestAssured.proxy("127.0.0.1", 7897);
        //设置基础URL
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";
        //忽略HTTPS证书
        RestAssured.useRelaxedHTTPSValidation();
    }

    /**
     * 发送 POST 请求（带 JSON Body）
     * @param path 接口路径，如 "/auth"
     * @param body JSON 字符串
     * @return 响应对象
     */
    public static Response post(String path, String body) {
        return given()
                .contentType(ContentType.JSON)  // 自动设置 Content-Type: applicat
                .body(body)
                .log().all()
        .when()
                .post(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 GET 请求（带路径参数）
     * @param path 接口路径，如 "/booking/1"
     * @return 响应对象
     */
    public static Response get(String path) {
        return given()
                .log().all()
        .when()
                .get(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 GET 请求（带 Token + 路径参数）
     * @param path 接口路径
     * @param token 认证 Token
     * @return 响应对象
     */
    public static Response getWithToken(String path, String token) {
        return given()
                .header("Cookie", "token= " + token)
                .log().all()
        .when()
                .get(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 PUT 请求（带 Token + JSON Body）
     */
    public static Response putWithToken(String path, String body, String token) {
        return given()
                .header("Cookie", "token= " + token)
                .contentType(ContentType.JSON)
                .body(body)
                .log().all()
        .when()
                .put(path)
        .then()
                .log().all()
                .extract().response();
    }

    /**
     * 发送 DELETE 请求（带 Token）
     */
    public static Response deleteWithToken(String path, String token) {
        return given()
                .header("Cookie", "token= " + token)
                .log().all()
        .when()
                .delete(path)
        .then()
                .log().all()
                .extract().response();
    }
}
