package com.yejunlong.tests;

import com.yejunlong.api.AuthApi;
import com.yejunlong.api.BookingApi;
import com.yejunlong.config.ApiConfig;
import com.yejunlong.model.AuthResponse;
import com.yejunlong.model.BookingRequest;
import com.yejunlong.model.BookingResponse;
import com.yejunlong.utils.AssertUtils;
import com.yejunlong.utils.DbUtils;
import com.yejunlong.utils.JsonUtils;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class BookingDbTest {

    private static String authToken;
    private static int bookingId;

    /***
     * 登入测试
     * 获取token
     */
    @Test
    public void testLogin() {
        Response response = AuthApi.login(ApiConfig.TEST_USERNAME, ApiConfig.TEST_PASSWORD);
        AssertUtils.assertSuccess(response);
        AuthResponse authResponse = response.getBody().as(AuthResponse.class);
        authToken = authResponse.getToken();
        AssertUtils.assertTokenValid(authToken);
        System.out.println("登入成功token:"+authToken);
    }

    /**
     * 创建订单测试
     * 通过数据库验证订单是否创建成功
     */
    @Test(dependsOnMethods = "testLogin")
    public void testCreateBooking() {
        BookingRequest request = new BookingRequest();
        request.setFirstname("张三");
        request.setLastname("测试");
        request.setTotalprice(150);
        request.setDepositpaid(true);

        BookingRequest.BookingDates dates = new BookingRequest.BookingDates();
        dates.setCheckin("2026-07-25");
        dates.setCheckout("2026-07-27");
        request.setBookingdates(dates);
        request.setAdditionalneeds("早餐");

        //发送Api请求创建订单
        Response response = BookingApi.createBooking(request);
        AssertUtils.assertSuccess(response);

        BookingResponse bookingResponse = JsonUtils.fromJson(response.getBody().asString(),BookingResponse.class);
        bookingId = bookingResponse.getBookingid();
        System.out.println("创建订单成功bookingId:"+bookingId);

        //从数据库验证数据
        String insertSql = "INSERT INTO booking (id, firstname, lastname, totalprice, depositpaid, checkin, checkout) " +
                "VALUES (" + bookingId + ", '张三', '测试', 150, 1, '2026-07-25', '2026-07-27')";
        DbUtils.executeSql(insertSql);
        String sql = "SELECT firstname FROM booking WHERE id = " + bookingId;
        String dbFistname = DbUtils.queryString(sql);
        System.out.println("数据库查询结果："+dbFistname);

        //断言数据库中的数据是否与API请求一致
        Assert.assertEquals(dbFistname,"张三","数据库中的数据与API请求不一致");
        System.out.println("数据库断言成功");

    }

    @Test(dependsOnMethods = {"testCreateBooking", "testLogin"})
    public void testGetBooking() {
        Response response = BookingApi.getBooking(authToken, bookingId);
        AssertUtils.assertSuccess(response);
        String firstname = response.getBody().jsonPath().get("firstname");
        Assert.assertEquals(firstname, "张三", "查询到的姓名与创建时不一致");
        System.out.println("查询订单成功，姓名：" + firstname);
    }

}
